﻿using System;


namespace NorthwindDAL
{
    public class IgnoreMapping : Attribute
    {
    }
}
